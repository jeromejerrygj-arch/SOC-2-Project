#!/usr/bin/env python3
"""Create dashboard data from the checked-in expected evaluation fixtures."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
EXPECTED = ROOT / "evals" / "expected"
POLICIES = ROOT / "evals" / "policies"
CHECK_IDS = [f"AC-{number:02d}" for number in range(1, 13)]


def main() -> None:
    cases = []
    totals = {"met": 0, "partial": 0, "missing": 0, "non_policy": 0}
    for expected_path in sorted(EXPECTED.glob("*.json")):
        expected = json.loads(expected_path.read_text(encoding="utf-8"))
        policy_name = expected_path.stem
        if expected.get("is_access_policy") is False:
            cases.append({"name": policy_name, "type": "Non-policy document", "statuses": {}})
            totals["non_policy"] += 1
            continue
        statuses = {check_id: expected[check_id] for check_id in CHECK_IDS}
        for value in statuses.values():
            totals[value] += 1
        cases.append({
            "name": policy_name,
            "type": "Prompt-injection test" if expected.get("_expects_suspicious_content") else "Access-control policy",
            "statuses": statuses,
        })
    payload = {"checks": CHECK_IDS, "cases": cases, "totals": totals, "policy_count": len(list(POLICIES.glob("*.md")))}
    (Path(__file__).parent / "data.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
