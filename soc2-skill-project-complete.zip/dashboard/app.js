const labels = { met: "Met", partial: "Partial", missing: "Missing" };

function makePills(statuses) {
  return Object.entries(statuses).map(([check, status]) =>
    `<span class="status ${status}" title="${check}: ${labels[status]}">${check}</span>`
  ).join("");
}

function render(cases, query = "") {
  const needle = query.toLowerCase().trim();
  const filtered = cases.filter((item) => `${item.name} ${item.type}`.toLowerCase().includes(needle));
  document.querySelector("#cases").innerHTML = filtered.map((item) => {
    const coverage = Object.keys(item.statuses).length ? makePills(item.statuses) : '<span class="chip non-policy">Not scored</span>';
    return `<tr><th scope="row">${item.name}</th><td>${item.type}</td><td class="coverage">${coverage}</td></tr>`;
  }).join("") || '<tr><td colspan="3" class="empty">No fixture matches this filter.</td></tr>';
}

fetch("data.json")
  .then((response) => response.json())
  .then((data) => {
    document.querySelector("#case-count").textContent = data.policy_count;
    document.querySelector("#met-count").textContent = data.totals.met;
    document.querySelector("#partial-count").textContent = data.totals.partial;
    document.querySelector("#missing-count").textContent = data.totals.missing;
    render(data.cases);
    document.querySelector("#filter").addEventListener("input", (event) => render(data.cases, event.target.value));
  })
  .catch(() => { document.querySelector("#cases").innerHTML = '<tr><td colspan="3" class="empty">Unable to load dashboard data. Run dashboard/build_data.py.</td></tr>'; });
