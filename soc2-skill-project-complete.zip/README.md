# Access Policy Gap Check

This repository contains a Claude skill that reviews a startup access-control
policy against a SOC 2-aligned readiness checklist. It returns a validated,
strict JSON assessment; it does not provide a SOC 2 audit opinion.

## Use the skill

Place the `access-policy-gap-check` directory under `.claude/skills/` in a
Claude-enabled project. Give Claude an access-control policy and ask for a
SOC 2 readiness gap check. The skill reads the checklist, emits the required
JSON schema, and validates that its evidence quotes are present in the policy.

## Evaluate it

The fixture set includes 10 policies covering strong controls, omissions,
vague language, a non-policy document, and prompt injection.

```sh
python3 evals/run_evals.py
python3 evals/run_evals.py --results-dir evals/results
```

The first command checks the fixture integrity. The second compares skill
outputs in `evals/results/` to the expected control statuses.

## Dashboard

Serve the repository locally and open `dashboard/index.html` to inspect the
evaluation suite. For example: `python3 -m http.server 8000`, then open
`http://localhost:8000/dashboard/`.
