#!/usr/bin/env python3
"""Check evaluation fixtures and optionally score skill result JSON files.

Usage:
    python3 evals/run_evals.py
    python3 evals/run_evals.py --results-dir /path/to/results

Results must use the policy filename with a `.json` suffix, for example
`01-strong.json` for `evals/policies/01-strong.md`.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
POLICIES = ROOT / "policies"
EXPECTED = ROOT / "expected"
CHECK_IDS = [f"AC-{number:02d}" for number in range(1, 13)]


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("must contain a JSON object")
    return value


def validate_fixture_pair(policy: Path, expected: Path) -> list[str]:
    errors: list[str] = []
    if not policy.read_text(encoding="utf-8").strip():
        errors.append("policy is empty")
    data = load_json(expected)
    if data.get("is_access_policy") is False:
        if any(key.startswith("AC-") for key in data):
            errors.append("non-policy fixture must not include control statuses")
        return errors
    for check_id in CHECK_IDS:
        if data.get(check_id) not in {"met", "partial", "missing"}:
            errors.append(f"{check_id} must be met, partial, or missing")
    return errors


def score_result(actual: dict, expected: dict) -> list[str]:
    errors: list[str] = []
    if actual.get("is_access_policy") != expected.get("is_access_policy", True):
        errors.append("is_access_policy does not match expected value")
        return errors
    if expected.get("_expects_suspicious_content") and not actual.get("suspicious_content"):
        errors.append("expected suspicious_content to be reported")
    actual_findings = {item.get("check_id"): item.get("status") for item in actual.get("findings", []) if isinstance(item, dict)}
    for check_id in CHECK_IDS:
        if expected.get(check_id) != actual_findings.get(check_id):
            errors.append(f"{check_id}: expected {expected.get(check_id)!r}, got {actual_findings.get(check_id)!r}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", type=Path, help="directory containing skill JSON output")
    args = parser.parse_args()

    policy_files = sorted(POLICIES.glob("*.md"))
    fixture_errors = 0
    scored = 0
    scoring_errors = 0
    for policy in policy_files:
        expected_path = EXPECTED / f"{policy.stem}.json"
        if not expected_path.is_file():
            print(f"FAIL {policy.name}: missing expected result")
            fixture_errors += 1
            continue
        try:
            errors = validate_fixture_pair(policy, expected_path)
        except ValueError as exc:
            errors = [str(exc)]
        if errors:
            fixture_errors += 1
            print(f"FAIL {policy.name}: {'; '.join(errors)}")
        else:
            print(f"OK   {policy.name}: fixture valid")

        if args.results_dir:
            result_path = args.results_dir / f"{policy.stem}.json"
            if not result_path.is_file():
                scoring_errors += 1
                print(f"FAIL {policy.name}: result file missing")
                continue
            try:
                scoring = score_result(load_json(result_path), load_json(expected_path))
            except ValueError as exc:
                scoring = [str(exc)]
            scored += 1
            if scoring:
                scoring_errors += 1
                print(f"FAIL {policy.name}: {'; '.join(scoring)}")
            else:
                print(f"PASS {policy.name}: expected statuses matched")

    print(f"\nFixtures: {len(policy_files) - fixture_errors}/{len(policy_files)} valid")
    if args.results_dir:
        print(f"Scored: {scored - scoring_errors}/{scored} passed")
    return 1 if fixture_errors or scoring_errors else 0


if __name__ == "__main__":
    sys.exit(main())
