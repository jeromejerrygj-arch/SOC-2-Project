Cedarpoint Analytics: Access Control Policy
Policy owner: Director of Security
Version 3.0, effective 2026-07-01
Review frequency: annually, or after any major system change

1. Granting access
1.1 We grant access only after a written request has been approved by the requester's manager and by the owner of the system concerned.
1.2 We follow least privilege. Every employee is assigned to one of four roles (Analyst, Engineer, Operations, or Finance), and each role carries only the access that its work requires.

2. Authentication
2.1 Multi-factor authentication is mandatory for all employees and contractors on email, the identity provider, the cloud platform, and every system that holds customer data.
2.2 Passwords must be at least 15 characters long. All staff sign in through single sign-on and must keep any remaining credentials in the company password manager.
2.3 Each person has a personal account. Shared accounts and shared credentials are not allowed.

3. Reviewing and removing access
3.1 System owners review all user access to their systems every quarter. The Director of Security checks that every review has been completed.
3.2 We remove a leaver's access within 4 hours of their departure time. When an employee changes role, their old-role access is removed within 3 business days.

4. Privileged access
4.1 Administrative access is held only by named members of the Platform team. Each administrator uses a separate admin account, and every administrative action is recorded in the audit log.

5. Remote access
5.1 Remote connections to internal systems must use the company VPN and multi-factor authentication.

6. Logging
6.1 We keep sign-in logs and administrative audit logs for 13 months. The security team reviews alerts from these logs every week.

7. Exceptions and enforcement
7.1 Anyone who needs an exception must submit a written request, which the Director of Security approves or declines.
7.2 Violations of this policy lead to disciplinary action, up to and including dismissal.
