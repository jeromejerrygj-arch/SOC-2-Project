# Northwind Labs Access Control Policy

Version: 1.2
Owner: Head of IT
Last reviewed: 2026-09-01
This policy is reviewed annually.

## 1. Access approval
All new access to company systems must be requested through the IT ticketing system and approved by the requester's manager and the system owner before access is granted.

## 2. Least privilege
Access is granted on a least-privilege basis. Each employee is assigned a role (Engineering, Support, Finance, or Admin), and access is limited to what that role requires.

## 3. Multi-factor authentication
Multi-factor authentication is required for all employees on email, the cloud console, the source code repository, and all production systems.

## 4. Access reviews
The IT Manager reviews user access to all production systems every quarter. Unneeded access is removed within 5 business days of the review.

## 5. Offboarding and role changes
Access for departing employees is revoked within 24 hours of their last day. When an employee changes roles, their previous access is removed within 5 business days.

## 6. Privileged access
Administrative access is limited to the Platform team. Administrators must use separate admin accounts, and all privileged actions are logged.

## 7. Unique accounts
Every user has a unique account. Shared accounts and shared credentials are prohibited.

## 8. Passwords
Passwords must be at least 14 characters. All employees must use the company password manager, and single sign-on is used wherever supported.

## 9. Remote access
Remote access to internal systems requires the company VPN and multi-factor authentication.

## 10. Logging
Authentication and administrative access logs are retained for 12 months. The Security Lead reviews alerts on suspicious sign-in activity weekly.

## 11. Exceptions and enforcement
Exceptions must be requested in writing and approved by the Head of IT. Violations of this policy may result in disciplinary action, up to and including termination.
