# Northwind Labs IT and Security Policy

Version: 1.1
Owner: Security Lead
Last reviewed: 2026-09-01
This policy is reviewed annually.

## 1. Purpose and scope
This policy sets out how Northwind Labs protects its systems, data, and equipment. It applies to all employees and contractors.

## 2. Acceptable use
Company devices are for business use. Employees must not install unapproved software. Passwords must be at least 12 characters and stored in the company password manager.

## 3. Data classification
Company data is classified as Public, Internal, or Confidential. Confidential data must be encrypted at rest and in transit.

## 4. Access control
Access requests must be approved by the requester's manager. Access follows least privilege: staff receive only the access required for their role. Multi-factor authentication is required for all staff on email and production systems. Shared accounts are not permitted. Access is removed when staff leave the company.

## 5. Remote work
Staff working remotely must connect to internal systems through the company VPN.

## 6. Incident response
Security incidents must be reported to the Security Lead within 24 hours. Each incident is recorded in the incident tracker and reviewed after resolution.

## 7. Backups
Production data is backed up daily. Backups are encrypted, and restore tests are performed twice a year.

## 8. Vendor management
Vendor contracts are reviewed annually. New vendors that handle Confidential data must complete a security questionnaire.

## 9. Training
All staff complete security awareness training annually.

## 10. Exceptions and enforcement
Exceptions to this policy require written approval from the Security Lead. Violations may result in disciplinary action.
