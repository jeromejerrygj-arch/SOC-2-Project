# Northwind Labs Access Control Policy

Owner: IT Team

## 1. Purpose
Northwind Labs is committed to protecting company information and systems from unauthorized access.

## 2. Access approval
Access to company systems must be authorized before it is granted.

## 3. Least privilege
Access follows the principle of least privilege.

## 4. Authentication
Multi-factor authentication is recommended where possible. Passwords must be strong and complex.

## 5. Access reviews
User access is reviewed periodically to make sure it remains appropriate.

## 6. Offboarding
Access is removed promptly when employees leave the company.

## 7. Privileged access
Privileged access is restricted to those who need it.

## 8. Remote access
Remote access is secured appropriately.

## 9. Monitoring
Systems are monitored for suspicious activity.

## 10. Violations
Violations of this policy may result in disciplinary action.
