ACCESS POLICY (IT notes)
Owner: CTO
Updated Jan 2026

--- getting access ---
* new access = ask your manager first
* manager approves in the #it-requests channel, THEN IT sets it up
* nobody gets access just because they asked nicely

access levels
- everyone gets the minimum they need for their job
- levels follow team: eng / support / finance
- no "just in case" access

** MFA **
MFA = ON for everything. Email, AWS, GitHub, prod. Founders too.

accounts: one person, one login. no shared logins. ever.

admin stuff
CTO + 2 senior engineers only. separate admin login, not your normal one.

who checks?
access review every 6 months. CTO does it.

people leaving
leavers lose access same day.

passwords -> see Password Standard doc

if you need an exception: get CTO sign-off in writing.
breaking these rules can lead to disciplinary action.
