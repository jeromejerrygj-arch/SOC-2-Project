# Harbourline Software Access Control Policy

Document owner: VP Engineering
Version: 1.4
Effective date: 2026-08-15
Review cycle: This policy is reviewed every 12 months.

## 1. Requesting access
Access to any system must be requested in writing and approved by the requester's line manager before it is provisioned.

## 2. Role-based access
Harbourline follows the principle of least privilege. Access is assigned by role (Developer, Support, Sales, or Finance) and limited to what the role needs.

## 3. Strong authentication
All staff must use multi-factor authentication when signing in to email, the cloud console, and the code repository.

## 4. Quarterly access review
System owners review who has access to their systems once per quarter and remove anything that is no longer needed.

## 5. Leavers and movers
Access is revoked within one business day of an employee's departure. When someone changes team, access from the old role is removed within five business days.

## 6. Administrator access
Administrator rights are limited to the Infrastructure team and must be approved by the VP Engineering. All administrator actions are logged.

## 7. Credentials
Passwords must be at least 16 characters and stored in the company password manager.

## 8. Working remotely
Remote access to internal systems is permitted only through the company VPN with multi-factor authentication.

## 9. Audit logs
Sign-in and administrator activity logs are retained for one year. The security team reviews alerts weekly.

## 10. Exceptions
Exceptions require written approval from the VP Engineering. Policy violations may result in disciplinary action.
