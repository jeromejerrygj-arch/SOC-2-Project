# Northwind Labs Employee Conduct and Leave Policy

Version: 3.1
Owner: People Operations

## 1. Working hours
Standard working hours are 9:00 to 17:30, Monday to Friday. Employees may agree flexible hours with their manager.

## 2. Annual leave
Full-time employees receive 20 days of paid annual leave per year, plus public holidays. Leave requests should be submitted at least two weeks in advance through the HR portal.

## 3. Sick leave
Employees who are unwell should notify their manager before the start of their working day. A medical note is required after three consecutive days of absence.

## 4. Parental leave
Employees are entitled to parental leave in line with provincial law. Please speak with People Operations about your options.

## 5. Workplace conduct
All employees are expected to treat colleagues with respect. Harassment and discrimination of any kind are not tolerated.

## 6. Office and equipment
Employees are responsible for company property, including laptops and office keycards. Lost or stolen equipment should be reported to People Operations on the same day. Keep your laptop password private.

## 7. Expenses
Business expenses are reimbursed when submitted with receipts within 30 days. Expenses over $500 require manager approval in advance.

## 8. Performance reviews
Performance reviews take place twice a year. Employees will receive feedback from their manager and have the chance to set goals for the next period.
