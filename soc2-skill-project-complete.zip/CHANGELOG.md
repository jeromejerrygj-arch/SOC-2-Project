# Changelog

## 1.0.0

- Completed the 12-control SOC 2-aligned access-policy checklist.
- Added ten evaluation policies and expected control-status fixtures.
- Added fixture validation and optional result scoring.
- Hardened result validation for JSON shape, policy type, evidence quotes, and
  suspicious-content quotes.
- Added the evaluation dashboard.
