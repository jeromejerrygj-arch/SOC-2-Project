# Access Control Policy Checklist (SOC 2-aligned)

Evaluate each check independently. Judge only what the policy text says.
Do not assume a control exists because it is common practice.

## General rules
- "Vague" wording is any term without a concrete value, such as
  "periodically", "regularly", "promptly", "as needed", "appropriate",
  "when necessary". A vague statement is PARTIAL, never MET.
- A policy that only says "see [other policy]" without stating the
  requirement is PARTIAL for that check. Note the reference in the gap.
- A policy statement that is clearly aspirational ("we aim to",
  "should ideally") is PARTIAL.
- Evidence must be an exact quote. If you cannot quote it, it is MISSING.

---

## AC-01: Access approval before granting
**Requirement:** New access is requested and approved by an authorized
person before it is granted.
**Mapping:** CC6.2
**MET:** States that access requires approval and names the approver role
(e.g., manager, system owner) or a defined request process.
**PARTIAL:** Says access is "authorized" or "approved" with no approver
or process named.
**MISSING:** No mention of approval before access is granted.

## AC-02: Least privilege / role-based access
**Requirement:** Access is limited to what each person needs for their job.
**Mapping:** CC6.1, CC6.3
**MET:** Explicitly requires least privilege or need-to-know AND ties
access to roles or job function.
**PARTIAL:** Mentions least privilege as a principle but does not say
how it is applied (no roles, no process).
**MISSING:** No mention.

## AC-03: Multi-factor authentication
**Requirement:** MFA is required for access to critical systems.
**Mapping:** CC6.1
**MET:** Requires MFA AND states the scope (e.g., all employees, admin
accounts, production systems, cloud console).
**PARTIAL:** Mentions MFA as "recommended", "where possible", or with
no scope.
**MISSING:** No mention of MFA or multi-factor authentication.

## AC-04: Periodic access reviews
**Requirement:** User access is reviewed on a defined schedule.
**Mapping:** CC6.3
**MET:** States a specific frequency (e.g., quarterly, every 6 months)
AND an owner or reviewer role.
**PARTIAL:** Mentions reviews but with vague frequency ("periodically")
or no owner.
**MISSING:** No mention of access reviews.

## AC-05: Timely access removal (offboarding)
**Requirement:** Access is removed when someone leaves or changes roles.
**Mapping:** CC6.2, CC6.3
**MET:** States a concrete timeframe (e.g., within 24 hours, same
business day) for termination, and addresses role changes.
**PARTIAL:** Says access is removed "promptly" or "upon termination"
with no timeframe, OR covers termination but not role changes.
**MISSING:** No mention.

## AC-06: Privileged / administrative access
**Requirement:** Admin access is restricted and handled more strictly
than standard access.
**Mapping:** CC6.1, CC6.3
**MET:** Defines who may hold privileged access AND at least one
additional control (separate admin accounts, extra approval, logging,
or more frequent review).
**PARTIAL:** Mentions privileged access but only says it is "restricted".
**MISSING:** No mention.

## AC-07: Unique user IDs, no shared accounts
**Requirement:** Each person has their own account; shared credentials
are prohibited.
**Mapping:** CC6.1
**MET:** Explicitly requires unique IDs or prohibits shared accounts.
**PARTIAL:** Implies individual accounts but never states the rule.
**MISSING:** No mention.

## AC-08: Authentication / password standards
**Requirement:** Credential requirements are defined.
**Mapping:** CC6.1
**MET:** States concrete requirements (e.g., minimum length, password
manager required, SSO) or references a specific standard.
**PARTIAL:** Says passwords must be "strong" or "complex" with no detail.
**MISSING:** No mention.

## AC-09: Secure remote access
**Requirement:** Remote access to company systems is controlled.
**Mapping:** CC6.6
**MET:** States how remote access is secured (e.g., VPN, zero-trust
tool, MFA-gated SSO) for systems that need it.
**PARTIAL:** Mentions remote access is allowed or "secured" with no
mechanism.
**MISSING:** No mention.

## AC-10: Access logging and monitoring
**Requirement:** Access events, especially privileged ones, are logged
and reviewed.
**Mapping:** CC7.2 (related)
**MET:** States that access or authentication logs are kept AND reviewed
or alerted on.
**PARTIAL:** Says logs are kept with no review, or says "monitoring"
generally.
**MISSING:** No mention.

## AC-11: Policy ownership and review cycle
**Requirement:** The policy has an owner, version, and review schedule.
**Mapping:** CC5.3 (related)
**MET:** Names an owner role, includes a version or last-reviewed date,
and states a review frequency (e.g., annually).
**PARTIAL:** Has some of these but not all three.
**MISSING:** None of them.

## AC-12: Exceptions and enforcement
**Requirement:** There is a process for exceptions, and consequences
for violations.
**Mapping:** CC1.5 (related)
**MET:** Describes an exception/approval process OR disciplinary
consequences, and addresses both.
**PARTIAL:** Mentions only one of the two, or only vaguely.
**MISSING:** No mention.
git add .
git commit -m "Add access control checklist v1"