#!/usr/bin/env python3
"""Validate an access-policy gap-check result.

Usage:
    python3 validate_output.py RESULT.json POLICY.md

Exit code 0 = valid, 1 = problems found.
"""
import json
import re
import sys
from pathlib import Path

CHECKLIST = (
    Path(__file__).resolve().parent.parent / "references" / "access-checklist.md"
)
VALID_STATUS = {"met", "partial", "missing"}
REQUIRED_KEYS = [
    "policy_name",
    "is_access_policy",
    "suspicious_content",
    "findings",
    "summary",
]


def norm(text):
    """Collapse whitespace so line breaks don't cause false mismatches."""
    return re.sub(r"\s+", " ", text).strip()


def checklist_ids():
    text = CHECKLIST.read_text(encoding="utf-8")
    return re.findall(r"^## (AC-\d+)", text, flags=re.M)


def non_empty_str(value):
    return isinstance(value, str) and value.strip() != ""


def validate(result, policy_text):
    errors = []

    if not isinstance(result, dict):
        return ["Top-level JSON value must be an object"]

    for key in REQUIRED_KEYS:
        if key not in result:
            errors.append(f"Missing top-level field: {key}")
    if errors:
        return errors

    if not isinstance(result["suspicious_content"], list):
        errors.append("suspicious_content must be a list")
    elif not all(non_empty_str(item) for item in result["suspicious_content"]):
        errors.append("suspicious_content entries must be non-empty strings")
    if not non_empty_str(result["summary"]):
        errors.append("summary must be a non-empty string")
    if not non_empty_str(result["policy_name"]):
        errors.append("policy_name must be a non-empty string")
    if not isinstance(result["is_access_policy"], bool):
        errors.append("is_access_policy must be true or false")

    findings = result["findings"]
    if not isinstance(findings, list):
        return errors + ["findings must be a list"]

    # Wrong document type: no findings allowed
    if result["is_access_policy"] is False:
        if findings:
            errors.append("is_access_policy is false but findings is not empty")
        return errors

    # Check IDs: exactly the checklist's IDs, once each, in order
    expected = checklist_ids()
    got = [f.get("check_id") for f in findings if isinstance(f, dict)]
    for cid in expected:
        if cid not in got:
            errors.append(f"Missing finding for {cid}")
    for cid in got:
        if cid not in expected:
            errors.append(f"Unknown check_id: {cid}")
    for cid in set(got):
        if got.count(cid) > 1:
            errors.append(f"Duplicate finding for {cid}")
    if not errors and got != expected:
        errors.append("Findings are not in checklist order")

    policy_norm = norm(policy_text)

    for item in result["suspicious_content"]:
        if isinstance(item, str) and norm(item) not in policy_norm:
            errors.append(f"suspicious_content quote not found in policy: {item[:60]!r}")

    for f in findings:
        if not isinstance(f, dict):
            errors.append("Each finding must be an object")
            continue
        cid = f.get("check_id", "?")
        status = f.get("status")
        quote = f.get("evidence_quote")
        gap = f.get("gap")
        fix = f.get("suggested_fix")

        if status not in VALID_STATUS:
            errors.append(f"{cid}: invalid status {status!r}")
            continue

        if status in ("met", "partial"):
            if not non_empty_str(quote):
                errors.append(f"{cid}: {status} requires an evidence_quote")
            elif norm(quote) not in policy_norm:
                errors.append(f"{cid}: quote not found in policy: {quote[:60]!r}")
        else:  # missing
            if quote is not None:
                errors.append(f"{cid}: missing status must have null evidence_quote")

        if status == "met":
            if gap is not None or fix is not None:
                errors.append(f"{cid}: met must have null gap and suggested_fix")
        else:
            if not non_empty_str(gap):
                errors.append(f"{cid}: {status} requires a gap")
            if not non_empty_str(fix):
                errors.append(f"{cid}: {status} requires a suggested_fix")

    return errors


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 validate_output.py RESULT.json POLICY.md")
        sys.exit(1)

    result_path, policy_path = sys.argv[1], sys.argv[2]
    try:
        result = json.loads(Path(result_path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"INVALID: output is not valid JSON ({e})")
        sys.exit(1)

    policy_text = Path(policy_path).read_text(encoding="utf-8")
    errors = validate(result, policy_text)

    if errors:
        print(f"INVALID: {len(errors)} problem(s)")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)

    print("OK")
if __name__ == "__main__":
    main()
