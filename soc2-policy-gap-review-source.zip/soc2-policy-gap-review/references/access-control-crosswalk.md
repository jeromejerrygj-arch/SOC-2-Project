# Practical SOC 2 access-control crosswalk (v1.0)

Use this compact checklist for policy-text readiness only. It maps common
SOC 2 logical-access expectations to policy statements; it is not an AICPA
publication or a substitute for the trust services criteria.

| ID | Policy requirement | Default severity | What counts as covered |
|---|---|---|---|
| AC-01 | Maintain an inventory of systems and accounts in scope. | Medium | Names an owner and a maintained inventory/register. |
| AC-02 | Grant access through approval based on job role and least privilege. | High | Requires an approver, role/business need, and least privilege. |
| AC-03 | Require MFA for production, cloud administration, and remote access. | Critical | Explicitly requires MFA for all three applicable areas. |
| AC-04 | Remove access promptly on termination and change it on role transfer. | High | Covers both offboarding and role changes with a time expectation or trigger. |
| AC-05 | Review privileged and user access periodically. | High | States scope, accountable owner, and review cadence. |
| AC-06 | Prohibit shared accounts or tightly govern documented exceptions. | Medium | Prohibits shared credentials or defines an approved, logged exception process. |
| AC-07 | Require unique identities and protect credentials/secrets. | High | Requires individual accounts and addresses password/secret handling. |
| AC-08 | Log and monitor privileged access and authentication events. | Medium | Identifies events and an expectation to review or alert on them. |
| AC-09 | Define an access-control policy owner and review/update cadence. | Low | Names an owner and periodic review or material-change trigger. |
| AC-10 | Require third-party/vendor access approval, least privilege, and removal. | High | Covers approval, bounded access, and removal when the engagement ends. |

### Interpreting partial coverage

Mark a control `Partial` when the policy names the topic but omits a required
element in the table. Examples: MFA for "admin systems" but not remote access;
quarterly reviews without scope or accountable owner; offboarding without role
transfers. Mark it `Missing` only when no relevant language appears.
