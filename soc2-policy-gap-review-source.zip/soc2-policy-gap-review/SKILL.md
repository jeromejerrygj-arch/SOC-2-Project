---
name: soc2-policy-gap-review
description: Review a startup access-control policy against a practical SOC 2 access-control crosswalk and return evidence-grounded gaps in a fixed Markdown format. Use for policy readiness reviews, not for SOC 2 attestation or legal advice.
---

# SOC 2 Policy Gap Review

Review the policy supplied by the user against the access-control checklist in
[references/access-control-crosswalk.md](references/access-control-crosswalk.md).

## Scope and evidence

- Review only the provided document and any explicitly supplied context. Do not
  infer that an operational practice exists because it would be customary.
- Treat the crosswalk as a practical readiness baseline, not the official AICPA
  criteria, a complete SOC 2 program, or an audit opinion.
- A statement counts as evidence only when it explicitly covers the control's
  required elements. Note partial coverage rather than calling it covered.
- Ask one concise question before reviewing if the policy text itself is absent.

## Output contract

Return exactly these sections and preserve their order. Use `None` when there
are no findings in a section. Do not add a prose preface or conclusion.

```markdown
# SOC 2 Access Control Policy Gap Review

## Review scope
- Document: <title or "Untitled policy">
- Framework: Practical SOC 2 access-control crosswalk, version 1.0
- Basis: <policy text and explicitly supplied context>

## Summary
- Findings: <number>
- Critical: <number> | High: <number> | Medium: <number> | Low: <number>

## Findings
| ID | Severity | Control | Status | Evidence | Gap | Recommended policy change |
|---|---|---|---|---|---|---|
| AC-01 | High | Access inventory | Missing | No inventory language found. | ... | ... |

## Questions for management
- <only questions whose answers could change a finding; otherwise `None`>

## Review limits
- This is a policy-text review, not evidence of operating effectiveness or a SOC 2 opinion.
```

Include one table row for every missing or partial control. `Status` must be
`Missing` or `Partial`; never list fully covered controls. Quote or closely
paraphrase the policy in `Evidence`, and use `No relevant language found.` for
missing controls. Severity comes from the crosswalk unless the supplied scope
clearly lowers the impact; explain any downgrade in the Gap cell.

## Quality check

Before responding, verify that every table row has a valid control ID, a
supported evidence statement, a concrete policy change, and a severity count
that matches the table. Read the crosswalk before beginning a review.
