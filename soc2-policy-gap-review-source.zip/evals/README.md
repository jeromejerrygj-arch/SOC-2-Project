# Evaluation set

Each sample is deliberately short so expected gaps are unambiguous. Run the
skill against each policy, then compare only the control IDs and statuses to
`expected_findings.json`. The expected findings evaluate policy-text analysis,
not operating effectiveness.

The cases cover missing controls, partial-control traps, a mostly complete
policy, and superficially reassuring language that lacks required details.
