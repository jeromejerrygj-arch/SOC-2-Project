# Access Control Policy

The Security Manager maintains the in-scope system and account inventory and
reviews this policy annually and after material changes. Access requires a
manager approver, documented business role, and least privilege. MFA is
required for production, cloud administration, and remote access. IT disables
access within one business day of termination and revises it on role transfer.
Security reviews all user and privileged access quarterly. Individual accounts
are required; shared accounts require a documented Security approval and
logging. Credentials and secrets must not be shared and are stored only in the
approved secrets manager. Vendor access requires Security approval, least
privilege, an expiry date, and removal when the engagement ends.
