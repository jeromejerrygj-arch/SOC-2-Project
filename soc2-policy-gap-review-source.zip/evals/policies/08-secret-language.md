# Access Control Policy

Employees must use individual accounts. Passwords must be strong.
