# Access Control Policy

Shared accounts are discouraged. Access requests require manager approval,
role justification, and least privilege.
