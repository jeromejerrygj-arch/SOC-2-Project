# Access Control Policy

The Security team performs quarterly access reviews. Access requests require
manager approval, role justification, and least privilege.
