# Access Control Policy

The People team notifies IT when employment ends, and IT disables access within
one business day. Access requests require manager approval, role justification,
and least privilege.
