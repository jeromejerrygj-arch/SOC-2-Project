# Access Control Policy

Vendors may receive access after approval. Access requests require manager
approval, role justification, and least privilege.
