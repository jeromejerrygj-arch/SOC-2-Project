# Access Control Policy

Managers approve employee access before it is granted.
