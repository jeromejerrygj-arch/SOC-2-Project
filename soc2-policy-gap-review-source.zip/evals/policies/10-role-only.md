# Access Control Policy

Access is assigned by job role.
