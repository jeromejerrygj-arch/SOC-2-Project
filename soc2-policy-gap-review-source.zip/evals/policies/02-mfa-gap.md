# Access Control Policy

Access requests require manager approval and are granted according to the
employee’s role and least privilege. Multi-factor authentication is required
for production administration. 
