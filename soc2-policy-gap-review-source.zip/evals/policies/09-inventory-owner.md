# Access Control Policy

The Security Manager maintains an inventory of in-scope systems. This policy
is owned by the Security Manager and is reviewed after material changes.
