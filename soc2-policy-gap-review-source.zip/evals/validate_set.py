#!/usr/bin/env python3
"""Validate structural invariants for the policy-review evaluation fixture."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).parent
CONTROL_IDS = {f"AC-{n:02d}" for n in range(1, 11)}


def main() -> None:
    manifest = json.loads((ROOT / "expected_findings.json").read_text())
    cases = manifest["cases"]
    assert len(cases) == 10, f"expected 10 cases, got {len(cases)}"
    seen = set()
    for case in cases:
        name = case["policy"]
        assert name not in seen, f"duplicate policy: {name}"
        seen.add(name)
        assert (ROOT / "policies" / name).is_file(), f"missing fixture: {name}"
        findings = case["expected"]
        missing = set(findings["missing"])
        partial = set(findings["partial"])
        assert missing <= CONTROL_IDS and partial <= CONTROL_IDS, f"invalid ID in {name}"
        assert not missing & partial, f"overlapping statuses in {name}"
    print(f"Validated {len(cases)} policy fixtures and expected findings.")


if __name__ == "__main__":
    main()
