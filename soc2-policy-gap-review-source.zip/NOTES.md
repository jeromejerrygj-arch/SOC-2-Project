# What broke and how it was fixed

## 1. Broad statements produced false coverage

Early review logic treated phrases such as “access is secure” and “managers
approve access” as complete controls. That hides material omissions. The
crosswalk now defines the minimum elements for each control and requires a
`Partial` finding when one is absent.

## 2. Output was hard to compare across reviews

Free-form summaries made it difficult to validate results or hand them to a
compliance owner. The skill now has a fixed section order, a findings table,
controlled statuses, and a count reconciliation check.

## 3. The review could overclaim assurance

Policy text cannot prove that access reviews, logging, or deprovisioning occur.
The scope statement and mandatory review limit now distinguish a document-gap
review from SOC 2 attestation and operating-effectiveness testing.

## 4. MFA and offboarding were prone to partial-credit errors

Policies often mention one target for MFA or termination without role changes.
The crosswalk and evals make these explicit partial cases, preventing a common
all-or-nothing classification mistake.
